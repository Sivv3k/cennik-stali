"""Cennik Stali - System cennikowy dla materiałów stalowych i aluminiowych."""

__version__ = "0.1.0"
